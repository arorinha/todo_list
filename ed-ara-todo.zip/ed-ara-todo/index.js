const express = require("express");
const app = express();
const path = require("path");
const mongoose = require("mongoose");
require("./models/TodoCard");
const TodoCard = mongoose.model("todo_card");
const { engine } = require("express-handlebars");

app.use(express.json());
app.use(express.static(path.join(__dirname, "/")));
app.use(express.urlencoded({ extended: true }));

app.engine("hbs", engine({ defaultLayout: "main" }));
app.set("view engine", "hbs");

mongoose.Promise = global.Promise;
mongoose
  .connect("mongodb+srv://rafainho:deus123@cluster0.c4vc9ja.mongodb.net/test")
  .then(() => {
    console.log("banco ok...");
  })
  .catch((erro) => {
    console.log("erro " + erro);
  });

app.get("/", (req, res) => {
  TodoCard.find()
    .lean()
    .then((todoCards) => {
      res.render("todo", { todoCards: todoCards });
    })
    .catch((error) => {
      console.log("erro " + error);
      res.redirect("/");
    });
});

app.post("/new", (req, res) => {
  const todoCard = new TodoCard({
    title: req.body.title,
    description: req.body.description,
    isOk: false,
  });
  todoCard
    .save()
    .then(function () {
      console.log("todo salvo");
      res.redirect("/");
    })
    .catch((erro) => {
      console.log("erro: " + erro);
      res.redirect("/");
    });
});

app.post("/delete", (req, res) => {
  TodoCard.deleteOne({ id: req.body.id })
    .then(() => {
      console.log("deletado");
      res.redirect("/");
    })
    .catch((erro) => {
      console.log("erro: " + erro);
      res.redirect("/");
    });
});

app.post("/edit", (req, res) => {
  console.log("id: " + req.body.id);
  //TodoCard.findOne(_id: )
  /*
  TodoCard.updateOne(
    { id: req.body.id },
    { isOk: req.body.isOk == "true" ? false : true },
    (erro, docs) => {
      if (erro) {
        console.log("erro ao atualizar: " + erro);
        return res.redirect("/");
      }
      console.log("atualizado: " + docs);
      res.redirect("/");
    }
  );*/
  TodoCard.findOneAndUpdate(
    { _id: req.body.id },
    { isOk: req.body.isOk == "true" ? false : true },
    { new: false }
  )
    .then(() => {
      console.log("atualizado");
      res.redirect("/");
    })
    .catch((erro) => {
      console.log("Erro: " + erro);
      res.redirect("/");
    });
});

app.listen(1234, () => {
  console.log("serv ok...");
});
