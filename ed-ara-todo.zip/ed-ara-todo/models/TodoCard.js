const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const TodoCard = new Schema({
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  isOk: {
    type: Boolean,
    required: true,
  },
});

mongoose.model("todo_card", TodoCard);
